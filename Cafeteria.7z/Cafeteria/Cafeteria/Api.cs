﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    class Api
    {
        private Boolean isAdmin;

        public Boolean getisAdmin()
        {
            return isAdmin;
        }
        public void setIsAdmin(Boolean isadmin)
        {
            this.isAdmin = isadmin;
        }

        public double checkCoffe(bool cafe, bool espresso, bool machiatto, bool duplo)
        {
            if(cafe == true)
            {
                return 1.0;
            }
            if(espresso == true)
            {
                return 2.0;
            }
            if(machiatto == true)
            {
                return 4.0;
            }
            if(duplo == true)
            {
                return 3.0;
            }
            return 0.0;
        }

        public double checkAcompanhamentos(bool açucar, bool adosante, bool leite, bool cookie, bool nenhum)
        {
            if(açucar == true)
            {
                return 1.0;
            }
            if(adosante == true)
            {
                return 1.0;
            }
            if(leite == true)
            {
                return 3.0;
            }
            if(cookie == true)
            {
                return 4.0;
            }
            if(nenhum == true)
            {
                return 0.0;
            }
            return 0.0;
        }

        public double checkPrice(double valor1, double valor2)
        {
            return valor1 + valor2;
        }
    }
}
