﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Sell : Form
    {
        Api api = new Api();

        public string productName;

        string productAcompanhament;

        double preçoTotal;

        double preçoCafe;

        double preçoAcom;

        public Sell()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(cafe.Checked == true)
            {
                productName = "Café normal";
            }
            if(macchiato.Checked == true)
            {
                productName = "Café macchiato";
            }
            if(duplo.Checked == true)
            {
                productName = "Café duplo";
            }
            if(espresso.Checked == true)
            {
                productName = "Café espresso";
            }
            if(açucar.Checked == true)
            {
                productAcompanhament = "Açucar";
            }
            if(leite.Checked == true)
            {
                productAcompanhament = "Leite";
            }
            if(adosante.Checked == true)
            {
                productAcompanhament = "Adosante";
            }
            if(cookie.Checked == true)
            {
                productAcompanhament = "Cookie";
            }
            if(nenhum.Checked == true)
            {
                productAcompanhament = "Nenhum";
            }

            if (cafe.Checked == true || macchiato.Checked == true || duplo.Checked == true || espresso.Checked == true)
            {
                if (açucar.Checked == true || leite.Checked == true || adosante.Checked == true || cookie.Checked == true || nenhum.Checked == true)
                {
                    Double valorCafe = api.checkCoffe(cafe.Checked, espresso.Checked, macchiato.Checked, duplo.Checked);
                    coffePrice.Text = valorCafe.ToString() + " R$";

                    coffePrice.Font = new Font("Comic Sans MS", 14);
                    //bool açucar, bool adosante, bool leite, bool cookie, bool nenhum
                    Double valorAcompanhamento = api.checkAcompanhamentos(açucar.Checked, adosante.Checked, leite.Checked, cookie.Checked, nenhum.Checked);
                    AcomPrice.Text = valorAcompanhamento.ToString() + " R$";
                    AcomPrice.Font = new Font("Comic Sans MS", 14);

                    double valorTotal = api.checkPrice(valorCafe, valorAcompanhamento);

                    totalPrice.Text = valorTotal.ToString() + " R$";
                    totalPrice.Font = new Font("Comic Sans MS", 14);

                    preçoTotal = valorTotal;
                    preçoCafe = valorCafe;
                    preçoAcom = valorAcompanhamento;
                    preço.Show();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reciept reciept = new Reciept(productName, productAcompanhament, preçoTotal, preçoCafe, preçoAcom);
            reciept.Show();
        }

        private void Sell_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
