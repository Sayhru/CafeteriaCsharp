﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Form2 : Form
    {
        int pergunta;
        int a;

       public int cafeNormalValor;
        public int cafeEspresso;
        public int cafemacchiato;
        public int cafeduplo;

        public int açucar;
        public int leite;
        public int adosante;
        public int cookie;

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pergunta++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(textBox1.Text == "" && a == 0)
            {
                a++;
                textBox1.Text = "1";
            }
            if(pergunta == 0)
            {
                label1.Text = "Quanto stock de café normal você tem ?";
                try
                {
                    cafeNormalValor = int.Parse(textBox1.Text);
                } catch (Exception ex)
                {
                    textBox1.Text = "1";
                }

                }
            if(pergunta == 1)
            {
                label1.Text = "Quanto stock de café espresso você tem ?";
                try
                {
                    cafeEspresso = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
            if(pergunta == 2)
            {
                label1.Text = "Quanto stock de café macchiato você tem ?";
                try
                {
                    cafemacchiato = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
            if(pergunta == 3)
            {
                label1.Text = "Quanto stock de café duplo você tem ?";
                try
                {
                    cafeduplo = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
            if (pergunta == 4)
            {
                label1.Text = "Quanto stock de açucar você tem ?";
                try
                {
                    açucar = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
            if (pergunta == 5)
            {
                label1.Text = "Quanto stock de leite você tem ?";
                try
                {
                    leite = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
            if (pergunta == 6)
            {
                label1.Text = "Quanto stock de adosante você tem ?";
                try
                {
                   adosante = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
            if (pergunta == 7)
            {
                label1.Text = "Quanto stock de cookie você tem ?";
                button1.Hide();
                finish.Visible = true;
                finish.Show();
                try
                {
                    cookie = int.Parse(textBox1.Text);
                }
                catch (Exception ex)
                {
                    textBox1.Text = "1";
                }
            }
        }



        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Text = "1";
            finish.Hide();
        }

        private void finish_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
