﻿namespace Cafeteria
{
    partial class Funcionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Funcionario));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.stock = new System.Windows.Forms.Button();
            this.userifo = new System.Windows.Forms.Button();
            this.Venda = new System.Windows.Forms.Button();
            this.tela = new System.Windows.Forms.Panel();
            this.preço = new System.Windows.Forms.Panel();
            this.AcomPrice = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.coffePrice = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.totalPrice = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nenhum = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.cookie = new System.Windows.Forms.RadioButton();
            this.adosante = new System.Windows.Forms.RadioButton();
            this.leite = new System.Windows.Forms.RadioButton();
            this.açucar = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.duplo = new System.Windows.Forms.RadioButton();
            this.macchiato = new System.Windows.Forms.RadioButton();
            this.espresso = new System.Windows.Forms.RadioButton();
            this.cafe = new System.Windows.Forms.RadioButton();
            this.panelChanger = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tela.SuspendLayout();
            this.preço.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.YellowGreen;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.stock);
            this.panel1.Controls.Add(this.userifo);
            this.panel1.Controls.Add(this.Venda);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 535);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(25, 144);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(58, 59);
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(25, 459);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(47, 37);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 37);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // stock
            // 
            this.stock.BackColor = System.Drawing.Color.YellowGreen;
            this.stock.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stock.ForeColor = System.Drawing.SystemColors.Control;
            this.stock.Location = new System.Drawing.Point(12, 124);
            this.stock.Name = "stock";
            this.stock.Size = new System.Drawing.Size(241, 89);
            this.stock.TabIndex = 4;
            this.stock.Text = "StockViewer";
            this.stock.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.stock.UseVisualStyleBackColor = false;
            this.stock.Click += new System.EventHandler(this.button2_Click);
            // 
            // userifo
            // 
            this.userifo.BackColor = System.Drawing.Color.YellowGreen;
            this.userifo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userifo.ForeColor = System.Drawing.SystemColors.Control;
            this.userifo.Location = new System.Drawing.Point(12, 444);
            this.userifo.Name = "userifo";
            this.userifo.Size = new System.Drawing.Size(241, 67);
            this.userifo.TabIndex = 3;
            this.userifo.Text = "User-Info";
            this.userifo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.userifo.UseVisualStyleBackColor = false;
            this.userifo.Click += new System.EventHandler(this.userifo_Click);
            // 
            // Venda
            // 
            this.Venda.BackColor = System.Drawing.Color.YellowGreen;
            this.Venda.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Venda.ForeColor = System.Drawing.SystemColors.Control;
            this.Venda.Location = new System.Drawing.Point(12, 36);
            this.Venda.Name = "Venda";
            this.Venda.Size = new System.Drawing.Size(241, 67);
            this.Venda.TabIndex = 2;
            this.Venda.Text = "Sell";
            this.Venda.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Venda.UseVisualStyleBackColor = false;
            this.Venda.Click += new System.EventHandler(this.Venda_Click);
            // 
            // tela
            // 
            this.tela.BackColor = System.Drawing.Color.YellowGreen;
            this.tela.Controls.Add(this.preço);
            this.tela.Controls.Add(this.panel3);
            this.tela.Controls.Add(this.panel2);
            this.tela.Location = new System.Drawing.Point(284, 2);
            this.tela.Name = "tela";
            this.tela.Size = new System.Drawing.Size(1003, 535);
            this.tela.TabIndex = 1;
            // 
            // preço
            // 
            this.preço.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.preço.Controls.Add(this.AcomPrice);
            this.preço.Controls.Add(this.label5);
            this.preço.Controls.Add(this.coffePrice);
            this.preço.Controls.Add(this.label4);
            this.preço.Controls.Add(this.label3);
            this.preço.Controls.Add(this.totalPrice);
            this.preço.Controls.Add(this.button1);
            this.preço.Location = new System.Drawing.Point(488, 36);
            this.preço.Name = "preço";
            this.preço.Size = new System.Drawing.Size(512, 420);
            this.preço.TabIndex = 9;
            // 
            // AcomPrice
            // 
            this.AcomPrice.Location = new System.Drawing.Point(85, 176);
            this.AcomPrice.Multiline = false;
            this.AcomPrice.Name = "AcomPrice";
            this.AcomPrice.Size = new System.Drawing.Size(302, 33);
            this.AcomPrice.TabIndex = 22;
            this.AcomPrice.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(137, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(200, 25);
            this.label5.TabIndex = 21;
            this.label5.Text = "Accompaniment price";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // coffePrice
            // 
            this.coffePrice.Location = new System.Drawing.Point(85, 72);
            this.coffePrice.Multiline = false;
            this.coffePrice.Name = "coffePrice";
            this.coffePrice.Size = new System.Drawing.Size(302, 33);
            this.coffePrice.TabIndex = 20;
            this.coffePrice.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(180, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 25);
            this.label4.TabIndex = 19;
            this.label4.Text = "Coffe Price";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(180, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 25);
            this.label3.TabIndex = 18;
            this.label3.Text = "Total Price:";
            // 
            // totalPrice
            // 
            this.totalPrice.Location = new System.Drawing.Point(85, 290);
            this.totalPrice.Multiline = false;
            this.totalPrice.Name = "totalPrice";
            this.totalPrice.Size = new System.Drawing.Size(302, 33);
            this.totalPrice.TabIndex = 17;
            this.totalPrice.Text = "";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.YellowGreen;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(142, 348);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(207, 50);
            this.button1.TabIndex = 0;
            this.button1.Text = "Finish purchase";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.nenhum);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.cookie);
            this.panel3.Controls.Add(this.adosante);
            this.panel3.Controls.Add(this.leite);
            this.panel3.Controls.Add(this.açucar);
            this.panel3.Location = new System.Drawing.Point(258, 37);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(203, 221);
            this.panel3.TabIndex = 8;
            // 
            // nenhum
            // 
            this.nenhum.AutoSize = true;
            this.nenhum.Location = new System.Drawing.Point(15, 188);
            this.nenhum.Name = "nenhum";
            this.nenhum.Size = new System.Drawing.Size(78, 20);
            this.nenhum.TabIndex = 16;
            this.nenhum.TabStop = true;
            this.nenhum.Text = "Nenhum";
            this.nenhum.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "Acompamento:";
            // 
            // cookie
            // 
            this.cookie.AutoSize = true;
            this.cookie.Location = new System.Drawing.Point(14, 145);
            this.cookie.Name = "cookie";
            this.cookie.Size = new System.Drawing.Size(71, 20);
            this.cookie.TabIndex = 9;
            this.cookie.TabStop = true;
            this.cookie.Text = "Cookie";
            this.cookie.UseVisualStyleBackColor = true;
            // 
            // adosante
            // 
            this.adosante.AutoSize = true;
            this.adosante.Location = new System.Drawing.Point(15, 106);
            this.adosante.Name = "adosante";
            this.adosante.Size = new System.Drawing.Size(86, 20);
            this.adosante.TabIndex = 8;
            this.adosante.TabStop = true;
            this.adosante.Text = "Adosante";
            this.adosante.UseVisualStyleBackColor = true;
            // 
            // leite
            // 
            this.leite.AutoSize = true;
            this.leite.Location = new System.Drawing.Point(15, 71);
            this.leite.Name = "leite";
            this.leite.Size = new System.Drawing.Size(57, 20);
            this.leite.TabIndex = 7;
            this.leite.TabStop = true;
            this.leite.Text = "Leite";
            this.leite.UseVisualStyleBackColor = true;
            // 
            // açucar
            // 
            this.açucar.AutoSize = true;
            this.açucar.Location = new System.Drawing.Point(15, 30);
            this.açucar.Name = "açucar";
            this.açucar.Size = new System.Drawing.Size(70, 20);
            this.açucar.TabIndex = 6;
            this.açucar.TabStop = true;
            this.açucar.Text = "Açucar";
            this.açucar.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.duplo);
            this.panel2.Controls.Add(this.macchiato);
            this.panel2.Controls.Add(this.espresso);
            this.panel2.Controls.Add(this.cafe);
            this.panel2.Location = new System.Drawing.Point(24, 36);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(203, 222);
            this.panel2.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Tipo de café:";
            // 
            // duplo
            // 
            this.duplo.AutoSize = true;
            this.duplo.Location = new System.Drawing.Point(13, 146);
            this.duplo.Name = "duplo";
            this.duplo.Size = new System.Drawing.Size(64, 20);
            this.duplo.TabIndex = 13;
            this.duplo.TabStop = true;
            this.duplo.Text = "Duplo";
            this.duplo.UseVisualStyleBackColor = true;
            // 
            // macchiato
            // 
            this.macchiato.AutoSize = true;
            this.macchiato.Location = new System.Drawing.Point(13, 107);
            this.macchiato.Name = "macchiato";
            this.macchiato.Size = new System.Drawing.Size(90, 20);
            this.macchiato.TabIndex = 12;
            this.macchiato.TabStop = true;
            this.macchiato.Text = "Macchiato";
            this.macchiato.UseVisualStyleBackColor = true;
            // 
            // espresso
            // 
            this.espresso.AutoSize = true;
            this.espresso.Location = new System.Drawing.Point(17, 72);
            this.espresso.Name = "espresso";
            this.espresso.Size = new System.Drawing.Size(86, 20);
            this.espresso.TabIndex = 11;
            this.espresso.TabStop = true;
            this.espresso.Text = "Espresso";
            this.espresso.UseVisualStyleBackColor = true;
            // 
            // cafe
            // 
            this.cafe.AutoSize = true;
            this.cafe.Location = new System.Drawing.Point(13, 31);
            this.cafe.Name = "cafe";
            this.cafe.Size = new System.Drawing.Size(100, 20);
            this.cafe.TabIndex = 10;
            this.cafe.TabStop = true;
            this.cafe.Text = "Café normal";
            this.cafe.UseVisualStyleBackColor = true;
            // 
            // panelChanger
            // 
            this.panelChanger.Enabled = true;
            this.panelChanger.Interval = 1;
            this.panelChanger.Tick += new System.EventHandler(this.panelChanger_Tick);
            // 
            // Funcionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1299, 539);
            this.Controls.Add(this.tela);
            this.Controls.Add(this.panel1);
            this.Name = "Funcionario";
            this.Text = "Funcionario";
            this.Load += new System.EventHandler(this.Funcionario_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tela.ResumeLayout(false);
            this.preço.ResumeLayout(false);
            this.preço.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel tela;
        private System.Windows.Forms.Button stock;
        private System.Windows.Forms.Button userifo;
        private System.Windows.Forms.Button Venda;
        private System.Windows.Forms.Timer panelChanger;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton cookie;
        private System.Windows.Forms.RadioButton adosante;
        private System.Windows.Forms.RadioButton leite;
        private System.Windows.Forms.RadioButton açucar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton duplo;
        private System.Windows.Forms.RadioButton macchiato;
        private System.Windows.Forms.RadioButton espresso;
        private System.Windows.Forms.RadioButton cafe;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel preço;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox coffePrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox totalPrice;
        private System.Windows.Forms.RadioButton nenhum;
        private System.Windows.Forms.RichTextBox AcomPrice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
