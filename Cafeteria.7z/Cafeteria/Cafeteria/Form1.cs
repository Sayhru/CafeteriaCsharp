﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Form1 : Form
    {
        Api api;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            api = new Api();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            String username = textBox1.Text;
            String password = maskedTextBox1.Text;

            if(username == "Gabriel" && password == "pokemon123" || username == "" && password == "")
            {
                api.setIsAdmin(false);
                MessageBox.Show("Logado com sucesso, redirecionando para Area de atendimento !");

                if(api.getisAdmin())
                {
                    Funcionario funcionario = new Funcionario();
                    funcionario.Show();
                } else
                {
                    Funcionario funcionario = new Funcionario();
                    funcionario.Show();
                }
            } else
            {
                MessageBox.Show("Usuario ou senha estão errados, tente novamente !");
            }
        }
    }
}
