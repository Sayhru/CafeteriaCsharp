﻿namespace Cafeteria
{
    partial class StockViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.duploNumero = new System.Windows.Forms.Label();
            this.cafeNormalNumero = new System.Windows.Forms.Label();
            this.espressonumero = new System.Windows.Forms.Label();
            this.macchiato = new System.Windows.Forms.Label();
            this.açucarNumero = new System.Windows.Forms.Label();
            this.leitenumero = new System.Windows.Forms.Label();
            this.adosante = new System.Windows.Forms.Label();
            this.cookienumero = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Café normal:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Espresso:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 36);
            this.label3.TabIndex = 2;
            this.label3.Text = "Macchiato:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 36);
            this.label4.TabIndex = 3;
            this.label4.Text = "Duplo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 374);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 36);
            this.label9.TabIndex = 9;
            this.label9.Text = "Cookie:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 326);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(159, 36);
            this.label10.TabIndex = 8;
            this.label10.Text = "Adosante:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 279);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 36);
            this.label11.TabIndex = 7;
            this.label11.Text = "Leite:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(12, 233);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 36);
            this.label12.TabIndex = 6;
            this.label12.Text = "Açucar:";
            // 
            // duploNumero
            // 
            this.duploNumero.AutoSize = true;
            this.duploNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.duploNumero.Location = new System.Drawing.Point(225, 48);
            this.duploNumero.Name = "duploNumero";
            this.duploNumero.Size = new System.Drawing.Size(27, 29);
            this.duploNumero.TabIndex = 10;
            this.duploNumero.Text = "0";
            // 
            // cafeNormalNumero
            // 
            this.cafeNormalNumero.AutoSize = true;
            this.cafeNormalNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cafeNormalNumero.Location = new System.Drawing.Point(225, 93);
            this.cafeNormalNumero.Name = "cafeNormalNumero";
            this.cafeNormalNumero.Size = new System.Drawing.Size(27, 29);
            this.cafeNormalNumero.TabIndex = 11;
            this.cafeNormalNumero.Text = "0";
            // 
            // espressonumero
            // 
            this.espressonumero.AutoSize = true;
            this.espressonumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.espressonumero.Location = new System.Drawing.Point(225, 138);
            this.espressonumero.Name = "espressonumero";
            this.espressonumero.Size = new System.Drawing.Size(27, 29);
            this.espressonumero.TabIndex = 12;
            this.espressonumero.Text = "0";
            // 
            // macchiato
            // 
            this.macchiato.AutoSize = true;
            this.macchiato.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.macchiato.Location = new System.Drawing.Point(225, 184);
            this.macchiato.Name = "macchiato";
            this.macchiato.Size = new System.Drawing.Size(27, 29);
            this.macchiato.TabIndex = 13;
            this.macchiato.Text = "0";
            // 
            // açucarNumero
            // 
            this.açucarNumero.AutoSize = true;
            this.açucarNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.açucarNumero.Location = new System.Drawing.Point(225, 240);
            this.açucarNumero.Name = "açucarNumero";
            this.açucarNumero.Size = new System.Drawing.Size(27, 29);
            this.açucarNumero.TabIndex = 14;
            this.açucarNumero.Text = "0";
            // 
            // leitenumero
            // 
            this.leitenumero.AutoSize = true;
            this.leitenumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leitenumero.Location = new System.Drawing.Point(225, 286);
            this.leitenumero.Name = "leitenumero";
            this.leitenumero.Size = new System.Drawing.Size(27, 29);
            this.leitenumero.TabIndex = 15;
            this.leitenumero.Text = "0";
            // 
            // adosante
            // 
            this.adosante.AutoSize = true;
            this.adosante.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adosante.Location = new System.Drawing.Point(225, 332);
            this.adosante.Name = "adosante";
            this.adosante.Size = new System.Drawing.Size(27, 29);
            this.adosante.TabIndex = 16;
            this.adosante.Text = "0";
            // 
            // cookienumero
            // 
            this.cookienumero.AutoSize = true;
            this.cookienumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cookienumero.Location = new System.Drawing.Point(225, 380);
            this.cookienumero.Name = "cookienumero";
            this.cookienumero.Size = new System.Drawing.Size(27, 29);
            this.cookienumero.TabIndex = 17;
            this.cookienumero.Text = "0";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(539, 74);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(222, 48);
            this.button1.TabIndex = 18;
            this.button1.Text = "Modificar Stock";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(539, 325);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(222, 48);
            this.button2.TabIndex = 19;
            this.button2.Text = "Remover numeros";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(539, 201);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(222, 48);
            this.button3.TabIndex = 20;
            this.button3.Text = "Refresh";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // StockViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.YellowGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cookienumero);
            this.Controls.Add(this.adosante);
            this.Controls.Add(this.leitenumero);
            this.Controls.Add(this.açucarNumero);
            this.Controls.Add(this.macchiato);
            this.Controls.Add(this.espressonumero);
            this.Controls.Add(this.cafeNormalNumero);
            this.Controls.Add(this.duploNumero);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StockViewer";
            this.ShowIcon = false;
            this.Text = "StockViewer";
            this.Load += new System.EventHandler(this.StockViewer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label duploNumero;
        private System.Windows.Forms.Label cafeNormalNumero;
        private System.Windows.Forms.Label espressonumero;
        private System.Windows.Forms.Label macchiato;
        private System.Windows.Forms.Label açucarNumero;
        private System.Windows.Forms.Label leitenumero;
        private System.Windows.Forms.Label adosante;
        private System.Windows.Forms.Label cookienumero;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button3;
    }
}