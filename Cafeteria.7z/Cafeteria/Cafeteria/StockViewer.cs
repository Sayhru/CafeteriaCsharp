﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class StockViewer : Form
    {

        Form2 form2 = new Form2();
        public StockViewer()
        {
            InitializeComponent();
        }

        private void StockViewer_Load(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            form2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            duploNumero.Text = form2.cafeduplo.ToString();
            cafeNormalNumero.Text = form2.cafeNormalValor.ToString();
            espressonumero.Text = form2.cafeEspresso.ToString();
            macchiato.Text = form2.cafemacchiato.ToString();

            açucarNumero.Text = form2.açucar.ToString();
            leitenumero.Text = form2.leite.ToString();
            adosante.Text = form2.adosante.ToString();
            cookienumero.Text = form2.cookie.ToString();

        }
    }
}
