﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Reciept : Form
    {

        String productName;
        string productAcompanhament;
        double valorTotal;
        double valorCafe;
        double valorAcom;

        public Reciept(String productName, string productAcompanhament, double preçoTotal, double preçoCafe, double preçoAcom)
        {
            this.productName = productName;
            this.productAcompanhament = productAcompanhament;
            this.valorTotal = preçoTotal;
            this.valorCafe = preçoCafe;
            this.valorAcom = preçoAcom;
            InitializeComponent();
        }

        private void Reciept_Load(object sender, EventArgs e)
        {
            preçoTabela.ForeColor = Color.Black;
            panel1.ForeColor = Color.Black;
            panel2.ForeColor = Color.Black;
            panel3.ForeColor = Color.Black;
            panel4.ForeColor = Color.Black;

            total.Text = "O valor total é: " + valorTotal + " R$";
            produtoNome.Text = productName;
            Acompanhamento.Text = productAcompanhament;
            acompanhamentoNome.Text = productAcompanhament;
            cafename.Text = productName;
            
           
        }
        Bitmap bmp;
        private void Printbutton_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
            Graphics mg = Graphics.FromImage(bmp);
            mg.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bmp, 0, 0);
        }

    }
}
