﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Funcionario : Form
    {
        Api api = new Api();

        int controladorTimer = 0;

        Boolean sell;
        Boolean sellHistory;
        Boolean stockViewer;
        Boolean userInfo;

        public Funcionario()
        {
            InitializeComponent();
        }

        //clear put things:
        public void putThings()
        {
            panel3.Show();
            panel2.Show();
        }

        //Clear old things:
        public void clearThings()
        {
            panel2.Hide();
            panel3.Hide();
        }

        public void loadForm(object form)
        {
            if (this.panel1.Controls.Count > 0)
            {
                this.tela.Controls.RemoveAt(0);
                Form f = form as Form;
                f.TopLevel = false;
                f.Dock = DockStyle.Fill;
                this.tela.Controls.Add(f);
                this.tela.Tag = f;
                f.Show();
            }
        }
        public void closeForm(object form)
        {
            Form f = form as Form;
            f.Close();
            f.Hide();
            f.Dispose();
        }
        private void Funcionario_Load(object sender, EventArgs e)
        {
            panel3.ForeColor = Color.Black;
            panel2.ForeColor = Color.Black;
            preço.ForeColor = Color.Black;
            preço.Hide();
        }

        private void Venda_Click(object sender, EventArgs e)
        {
            controladorTimer++;
            MessageBox.Show("a: " + controladorTimer);
            sell = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            controladorTimer++;
            MessageBox.Show("a: " + controladorTimer);
            stockViewer = true;
        }
        private void sellh_Click(object sender, EventArgs e)
        {
            controladorTimer++;
            sellHistory = true;
        }
        private void userifo_Click(object sender, EventArgs e)
        {
            controladorTimer++;
            MessageBox.Show("a: " + controladorTimer);
            userInfo = true;
        }
        private void panelChanger_Tick(object sender, EventArgs e)
        {
            if (sell == true)
            {
                if (controladorTimer >= 1)
                {
                    controladorTimer = 0;
                    Sell a1 = new Sell();
                    clearThings();
                    loadForm(a1);
                    sell = false;
                }
            }
            if (sellHistory == true)
            {
                if (controladorTimer >= 1)
                {
                    controladorTimer = 0;
                    MessageBox.Show("a");
                    sellHistory = false;
                }
            }
            if (stockViewer == true)
            {
                Sell a1 = new Sell();
                closeForm(a1);
                StockViewer a2 = new StockViewer();
                loadForm(a2);
                clearThings();
                controladorTimer = 0;
                stockViewer = false;
                
            }
            if (userInfo == true)
            {
                if (controladorTimer == 1)
                {
                    controladorTimer = 0;
                    UserInfo a1 = new UserInfo();
                    clearThings();
                    loadForm(a1);
                    userInfo = false; 
                }
            }
            if (cafe.Checked == true || macchiato.Checked == true || duplo.Checked == true || espresso.Checked == true)
            {
                if (açucar.Checked == true || leite.Checked == true || adosante.Checked == true || cookie.Checked == true || nenhum.Checked == true)
                {
                    Double valorCafe = api.checkCoffe(cafe.Checked, espresso.Checked, macchiato.Checked, duplo.Checked);
                    coffePrice.Text = valorCafe.ToString() + " R$";

                    coffePrice.Font = new Font("Comic Sans MS", 14);
                    //bool açucar, bool adosante, bool leite, bool cookie, bool nenhum
                    Double valorAcompanhamento = api.checkAcompanhamentos(açucar.Checked, adosante.Checked, leite.Checked, cookie.Checked, nenhum.Checked);
                    AcomPrice.Text = valorAcompanhamento.ToString() + " R$";
                    AcomPrice.Font = new Font("Comic Sans MS", 14);

                    double valorTotal = api.checkPrice(valorCafe, valorAcompanhamento);
                    totalPrice.Text = valorTotal.ToString() + " R$";
                    totalPrice.Font = new Font("Comic Sans MS", 14);
                    preço.Show();
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
